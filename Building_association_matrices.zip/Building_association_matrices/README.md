# Event–Indicator Association Matrix Demo (Financial Inclusion Forecasting)

Lightweight demo showing:
- Events (rows) vs Indicators (cols) association matrix
- Impact links (long format) that generate the matrix
- Baseline forecast from sparse observations
- Event-aware forecast using lag + duration impacts
- Scenario toggles (baseline / with-events / pessimistic / optimistic)
- Explainability: which events contributed how much to a chosen year

## Setup
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run (Streamlit)
```bash
streamlit run app.py
```

## Run tests
```bash
pytest -q
```

## Notes
- Data is generated in-code (small, beginner-friendly).
- Forecast baseline is a per-indicator linear trend using `np.polyfit`.
- Event effects apply using:
  - signed direction (increase/decrease)
  - lag in years
  - duration spread linearly across years
  - scenario scaling (optimistic/pessimistic)
